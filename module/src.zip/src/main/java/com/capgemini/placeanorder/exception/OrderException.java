package com.capgemini.placeanorder.exception;
public class OrderException extends Exception{
	   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrderException(String string) {
		super(string);
	}
	}
